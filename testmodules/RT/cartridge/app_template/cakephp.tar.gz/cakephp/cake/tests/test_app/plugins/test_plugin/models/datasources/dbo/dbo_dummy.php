<?php

class DboDummy extends DboSource {
	function connect() {
		return true;
	}
}
